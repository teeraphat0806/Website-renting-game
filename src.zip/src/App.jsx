import React, { useState } from "react";
import Home from './components/home/home';

function App() {
  return (
  <div>
      <Home/>
  </div>
  );
}

export default App;
